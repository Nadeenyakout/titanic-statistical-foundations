#!/usr/bin/env python
# coding: utf-8

# # Dataset

# In[2]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("C:/Users/yakou/Downloads/train.csv")


# # Part 1: Mathematical Foundations

# In[3]:


# Central Tendency Measures
columns = ['Age', 'Fare', 'SibSp']
for col in columns:
    print(f"{col} - Mean: {df[col].mean():.2f}, Median: {df[col].median():.2f}, Mode: {df[col].mode()[0]}")


# In[4]:


Q1 = df['Fare'].quantile(0.25)
Q3 = df['Fare'].quantile(0.75)
IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

outliers = df[(df['Fare'] < lower_bound) | (df['Fare'] > upper_bound)]

print(f"Number of outliers in Fare: {outliers.shape[0]}")


# In[5]:


plt.figure(figsize=(8, 5))
sns.boxplot(x=df['Fare'])
plt.title('Boxplot of Fare')
plt.show()


# In[6]:


# Histogram + KDE
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
sns.histplot(df['Age'].dropna(), kde=True)
plt.title('Distribution of Age')

plt.subplot(1, 2, 2)
sns.histplot(df['Fare'], kde=True)
plt.title('Distribution of Fare')

plt.show()


# # Part 2: Feature Engineering & Data Splitting

# In[7]:


# One-Hot Encoding
df_encoded = pd.get_dummies(df, columns=['Sex', 'Embarked'], drop_first=True)


# In[8]:


from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
df_encoded[['Age', 'Fare']] = scaler.fit_transform(df_encoded[['Age', 'Fare']])


# In[9]:


# FamilySize
df_encoded['FamilySize'] = df['SibSp'] + df['Parch'] + 1

# Title Extraction
df_encoded['Title'] = df['Name'].str.extract(' ([A-Za-z]+)\.', expand=False)
df_encoded['Title'] = df_encoded['Title'].replace(['Mlle', 'Ms'], 'Miss')
df_encoded['Title'] = df_encoded['Title'].replace(['Mme'], 'Mrs')
df_encoded['Title'] = df_encoded['Title'].replace(['Dr', 'Rev', 'Major', 'Col', 'Capt', 'Sir', 'Don', 'Jonkheer', 'Lady', 'Countess', 'Dona'], 'Rare')
df_encoded = pd.get_dummies(df_encoded, columns=['Title'], drop_first=True)


# In[10]:


from sklearn.model_selection import train_test_split

# Drop columns not needed for modeling
X = df_encoded.drop(['Survived', 'PassengerId', 'Name', 'Ticket', 'Cabin'], axis=1)
y = df_encoded['Survived']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Shapes
print(f"Train shape: {X_train.shape}, Test shape: {X_test.shape}")


# In[11]:


sns.countplot(x=y_train)
plt.title("Class Distribution in Training Set")
plt.show()

print(y_train.value_counts(normalize=True))


# In[ ]:




